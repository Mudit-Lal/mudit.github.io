<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6Lf6lLQZAAAAAAZLV3Q2CJubDzVQ3dqbHMZWYOgh");
define('SECRET_KEY',"6Lf6lLQZAAAAAMQd-JGzCLLfrG6JncNUadUOv2yN")
?>
